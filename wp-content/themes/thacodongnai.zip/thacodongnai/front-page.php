<?php get_header(); ?>
	<?php if( is_active_sidebar( 'home' ) ) dynamic_sidebar( 'home' ); ?>
<?php get_footer(); ?>