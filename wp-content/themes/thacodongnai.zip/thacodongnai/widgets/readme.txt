﻿WPSHARE247.COM WIDGETS
----------------------------------------
1/ Include dòng này vào functions.php
----------------------------------------
require_once get_parent_theme_file_path( '/widgets/widgets_index.php' );



----------------------------------------
2/ Hướng dẫn sử dụng
----------------------------------------
Mở file widgets_index.php

Gọi Widget ở trên dòng: //'add_new_here', //file exist : add_new_here.php

Gọi Widget ở trên dòng nếu là Widget bản pro: //'add_new_here_for_pro',