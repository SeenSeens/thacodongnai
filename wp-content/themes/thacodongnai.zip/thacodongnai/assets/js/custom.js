// Hàm chung để kích hoạt tab và panes
function activateTab(tab, tabLinks, tabPanes) {
    tabLinks.forEach(link => link.classList.remove("active"));
    tabPanes.forEach(pane => pane.classList.remove("active"));
    tab.classList.add("active");
    const targetPane = document.querySelector(tab.getAttribute("href"));
    targetPane.classList.add("active");
}

// Hàm chung để xử lý sự kiện khi nhấp vào nút tab
function setupTabClickEvent(tabLinks) {
    tabLinks.forEach(link => {
        link.addEventListener("click", function (event) {
            event.preventDefault();
            activateTab(link, tabLinks, tabPanes);
        });
    });
}

document.addEventListener("DOMContentLoaded", function () {
    const homeNewTabLinks = document.querySelectorAll(".home-new-tab .nav-link");
    const homeNewTabPanes = document.querySelectorAll(".home-new-tab .tab-pane");
    setupTabClickEvent(homeNewTabLinks);

    const homeProductTabLinks = document.querySelectorAll(".home-product-tab .nav-link");
    const homeProductTabPanes = document.querySelectorAll(".home-product-tab .tab-pane");
    setupTabClickEvent(homeProductTabLinks);

    const serviceTypeTabLinks = document.querySelectorAll(".service-type-tab .nav-link");
    const serviceTypeTabPanes = document.querySelectorAll(".service-type-tab .tab-pane");
    setupTabClickEvent(serviceTypeTabLinks);

    const newsTabLinks = document.querySelectorAll(".news-tab .nav-link");
    const newsTabPanes = document.querySelectorAll(".news-tab .tab-pane");
    setupTabClickEvent(newsTabLinks);

    const dropdownButtons = document.querySelectorAll('.product__wapper-left-filter-title');
    dropdownButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            var targetDiv = document.getElementById(button.id);
            targetDiv.classList.toggle('show');
        });
    });
});
